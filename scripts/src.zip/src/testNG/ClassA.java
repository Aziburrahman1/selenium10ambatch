package testNG;

import org.testng.annotations.Test;

public class ClassA {
	
	@Test()
	public void demo1()
	{
		System.out.println("The Demo Method");
	}

}
