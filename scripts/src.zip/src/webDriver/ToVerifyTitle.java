package webDriver;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class ToVerifyTitle {

	public static void main(String[] args) {
		
		 String expectedTitle = "Shoping";
		 System.setProperty("webdriver.gecko.driver", "./drivers/geckodriver.exe");
		 // Opening the browser
         WebDriver driver= new FirefoxDriver();
         //Enter the URL
         driver.get("https://www.flipkart.com/");
         String actualTitle = driver.getTitle();
         
         System.out.println("Actual Title :"+ actualTitle);
         System.out.println("Expected Title :"+ expectedTitle);
         
         if(actualTitle.contains(expectedTitle)) 
         {
        	 System.out.println("Pass: Title is verified");
        	 
	      }
         else
        	 System.out.println("Fail: Title is not verified");	
	}

}
