package webDriver;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriver.Options;
import org.openqa.selenium.WebDriver.Window;
import org.openqa.selenium.chrome.ChromeDriver;

public class ToMaximizeWindow1 {

	public static void main(String[] args) {
		

	    System.setProperty("webdriver.chrome.driver","./drivers/chromedriver.exe");
		WebDriver driver= new ChromeDriver();
		Options man = driver.manage();
		Window win = man.window();
		win.maximize();
		driver.get("https:/www.google.com/");	
	}

}
