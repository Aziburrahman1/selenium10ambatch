package webDriver;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ToSwitchBackToParentID {

	public static void main(String[] args) {


		
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		WebDriver driver= new ChromeDriver();
		driver.manage().window().maximize();
        driver.get("https://demo.actitime.com/login.do");
        //Fetching parent window Id
        String parentWindowId = driver.getWindowHandle();
        driver.findElement(By.linkText("actiTIME Inc")).click();
        // Fetching all the windows IDs
        Set<String> allWindowIDs = driver.getWindowHandles();
        
        for(String windowId:allWindowIDs) {
        	 // Switching any window
        	driver.switchTo().window(windowId);
        	if (!windowId.equals(parentWindowId)) {
        		driver.findElement(By.linkText("Try free")).click();
        		break;
        	}
        }

	}

}
